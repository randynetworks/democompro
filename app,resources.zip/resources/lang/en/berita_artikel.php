<?php
return [
	"heading" => "Our News & Articles",  
	"sub" => "Find the latest news and articles about Indonesian Sharia Reinsurance that you can view. Get the necessary insights through the latest news and detailed articles.", 
	"kembali" => "Back",
	"post" => "Previous Post",
	"badge_berita" => "News",
	"badge_artikel" => "Articles",
];