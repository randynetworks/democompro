<?php
return [
	"heading" => "Our Appreciation",    
	"sub" => "The Appreciation we offer are tangible evidence of your expertise and competency, demonstrating that you have the knowledge and skills necessary to excel in your chosen field, and are recognized by relevant professionals and industry."  

];