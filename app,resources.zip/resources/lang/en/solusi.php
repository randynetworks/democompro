<?php
return [
	"heading" => "Our Solution",
	"sub" => "This is Our Solution"
];
