<?php
return [
	"heading" => "Our Organizational Structure",   
	"sub" => "Welcome to our Organizational Structure page. Here, you can find complete information about our organizational structure, including key positions, key responsibilities, and the role of each team member in achieving our goals. We are committed to transparency and efficiency in every aspect of our operations.", 
];