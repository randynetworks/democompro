<?php
return [
	"heading" => "Solusi Kami",
	"sub" => "Ini Solusi Kami"
];
