<?php
return [
	"heading" => "Berita & Artikel Kami",
	"sub" => "Temukan berita dan artikel terkini tentang Reasuransi Syariah Indonesia yang dapat anda lihat. Dapatkan wawasan yang diperlukan melalui berita terbaru dan artikel terperinci.",    
	"kembali" => "Kembali",
	"post" => "Post Terdahulu",
	"badge_berita" => "Berita",
	"badge_artikel" => "Artikel",
];