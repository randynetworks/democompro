<?php
return [
	"heading" => "Struktur Organisasi Kami",  
	"sub" => "Selamat datang di halaman Struktur Organisasi kami. Di sini, Anda dapat menemukan informasi lengkap mengenai struktur organisasi kami, termasuk jabatan-jabatan penting, tanggung jawab utama, dan peran masing-masing anggota tim dalam mencapai tujuan kami. Kami berkomitmen untuk transparansi dan efisiensi dalam setiap aspek operasional kami." , 
];