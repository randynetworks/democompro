<?php
return [
	"heading" => "Penghargaan Kami",  
	"sub" => "Penghargaan yang kami tawarkan adalah bukti nyata dari keahlian dan kompetensi Anda, menunjukkan bahwa Anda memiliki pengetahuan dan keterampilan yang diperlukan untuk unggul dalam bidang yang Anda pilih, serta diakui oleh para profesional dan industri terkait."  
];